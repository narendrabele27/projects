package org.cap.emp.controller;

import javax.validation.Valid;

import org.cap.emp.dto.Employee;
import org.cap.emp.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService empService;
	
	@RequestMapping("/empForm")
	public String showEmployeeForm(ModelMap map){
	map.put("emp", new Employee());
	map.put("employees", empService.getAllEmployees()); 
	 
	 return "employee";
	}
	
	@RequestMapping(value="/saveEmployee",method=RequestMethod.POST)
	public String saveEmployeeDetails(@Valid @ModelAttribute("emp") Employee employee,
			BindingResult result){
		
		if(!result.hasErrors()){
			
			empService.saveEmployee(employee);
			return "redirect:empForm";
			
		}else{
			return "employee";
		}
		
			
		
	}
	
	
	
	@RequestMapping("/deleteEmp/{empId}")
	public String deleteEmployee(@PathVariable("empId") Integer eid){
		empService.deleteEmployee(eid);
		return "redirect:/empForm";
	}
	
	
	
	@RequestMapping("/updateEmp/{empId}")
	public String updateEmployee(@PathVariable("empId") Integer eid,ModelMap map){
		//return new ModelAndView("updateEmployee", "emp1", new Employee());
		map.put("emp1", new Employee());
		map.put("employee", empService.searchEmployee(eid));
		return "updateEmployee";
	}
	
	

}
