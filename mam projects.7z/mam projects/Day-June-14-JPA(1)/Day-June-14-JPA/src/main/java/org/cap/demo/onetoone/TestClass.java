package org.cap.demo.onetoone;

import org.cap.demo.Student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass {

	public static void main(String[] args) {
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Employee.class);
		config.addAnnotatedClass(Employee_Address.class);
		config.configure();
		
		//To Recreate Schema everyTime
		new SchemaExport(config).create(true, true);
		Employee_Address address=new Employee_Address();
		address.setEmp_address_id(11);
		address.setDoorNo("11/A");
		address.setStName("North Street");
		address.setCity("Chennai");
		
		Employee employee=new Employee(1001, "Tom", 23000, address);
		
		SessionFactory sessfactory=config.buildSessionFactory();
		Session session=sessfactory.openSession();
		session.getTransaction().begin();
		
		session.save(employee);
		//session.save(address);
		
		session.getTransaction().commit();
		session.close();

	}

}
