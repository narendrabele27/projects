package org.cap.demo.onetoone;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Employee_Address {
	
	@Id
	private int emp_address_id;
	private String doorNo;
	private String stName;
	private String city;
	
	@OneToOne(mappedBy="address",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private Employee employee;
	
	public Employee_Address(){}
	

	public Employee_Address(int emp_address_id, String doorNo, String stName, String city, Employee employee) {
		super();
		this.emp_address_id = emp_address_id;
		this.doorNo = doorNo;
		this.stName = stName;
		this.city = city;
		this.employee = employee;
	}

	public int getEmp_address_id() {
		return emp_address_id;
	}

	public void setEmp_address_id(int emp_address_id) {
		this.emp_address_id = emp_address_id;
	}

	public String getDoorNo() {
		return doorNo;
	}

	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}

	public String getStName() {
		return stName;
	}

	public void setStName(String stName) {
		this.stName = stName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	@Override
	public String toString() {
		return "Employee_Address [emp_address_id=" + emp_address_id + ", doorNo=" + doorNo + ", stName=" + stName
				+ ", city=" + city + ", employee=" + employee + "]";
	}
	
	
	

}
