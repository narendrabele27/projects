package org.cap.jdbc.dao;

import java.util.List;

import javax.sql.DataSource;

import org.cap.jdbc.demo.Company;
import org.cap.jdbc.demo.Employee;
import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDaoImpl implements EmployeeDao{
	
	private JdbcTemplate jdbcTemp;
	private DataSource dataSource;
	
	

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemp=new JdbcTemplate(dataSource);
	}



	@Override
	public void createEmployee(Employee employee) {
		
		String sql="insert into employees_company values(?,?,?,?)";
		
		jdbcTemp.update(sql, new Object[]{employee.getEmpId(), 
				employee.getEmpName(),employee.getSalary(),
				employee.getCompany().getCompanyId()});
		
		
		System.out.println("REcord Saved");
		
	}



	@Override
	public List<Employee> getAllEmployees() {
		
		String sql="select * from employees_company";
		List<Employee> employees= jdbcTemp.query(sql, new EmployeeRow());
		
		
		for(Employee emp:employees){
			Company company=findCompany(emp.getCompany().getCompanyId());
			
			emp.setCompany(company);
		}
		
		return employees;
	}
	
	
	public Company findCompany(int compId){
		Company company = null;
		
		List<Company> companies= getAllCompanys();
		
		for(Company company2:companies)
		{
			if(company2.getCompanyId()==compId){
				company=company2;
				break;
			}
		}
		
		return company;
	}
	

	public List<Company> getAllCompanys() {
		
		String sql="select * from company";
		List<Company> companies= jdbcTemp.query(sql, new CompanyRow());
		
		
		return companies;
	}



	@Override
	public String findEmployee(int empid) {
		String sql="select empName from employees_company where empId=?";
		
		String empName=jdbcTemp.queryForObject(sql,new Object[]{empid}, String.class);
		
		
		return empName;
	}

}
