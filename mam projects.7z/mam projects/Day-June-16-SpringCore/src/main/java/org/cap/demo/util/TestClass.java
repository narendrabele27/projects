package org.cap.demo.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("demoBeans.xml");
		MyCollection obj=(MyCollection)context.getBean("myCollect");
		
		System.out.println(obj.getNames());
		System.out.println(obj.getNumbers());
		System.out.println(obj.getDatas());
		System.out.println(obj.getMyProperty());
	}

}
