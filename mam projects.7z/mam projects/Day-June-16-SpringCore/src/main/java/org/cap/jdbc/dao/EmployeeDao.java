package org.cap.jdbc.dao;

import java.util.List;

import org.cap.jdbc.demo.Employee;

public interface EmployeeDao {
	
	public void createEmployee(Employee employee);
	
	public List<Employee> getAllEmployees();
	
	public String findEmployee(int empid);

}
