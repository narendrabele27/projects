app.controller("myController",function($scope){
	$scope.greetings="Hello! "
	$scope.firstName="TOM";
	
	 $scope.greetUser=function(){
		return $scope.greetings+" " + $scope.firstName;
		
	};
});