package org.cap.maps;

import java.util.HashMap;
import java.util.Set;

public class Database {

	HashMap<Employee, Salary> hmap = new HashMap<Employee, Salary>();

	void yoyo(Employee employee, Salary salary) {
		
		hmap.put(employee, salary);
		/*System.out.println(employee.getEmpid());
		System.out.println(hmap);
		*/

	}
	void viewall(){
		Set<Employee> setEmployee=hmap.keySet();
		Salary sal=new Salary();
		//sal=hmap.values(setEmployee);
	}
}