package org.cap.maps;

public class EmpInterImpl implements EmployeeInterface{

	public Employee createEmployee() {
		UserInteration ui=new UserInteration();
		Employee emp1=ui.getEmployeeDetails();
		return emp1;
	}

	public void viewEmployee() {
	
		UserInteration ui=new UserInteration();
		
	}

	public Salary createSalaryslip() {
		UserInteration ui=new UserInteration();
		Salary sal=ui.getSalaryDetails();
		return sal;
	}

}
