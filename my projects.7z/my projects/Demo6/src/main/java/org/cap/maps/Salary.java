package org.cap.maps;

public class Salary {
int noOfDayWork;
double salaryPerDay;
Salary(){
	
}
public Salary(int noOfDayWork, double salaryPerDay) {
	super();
	this.noOfDayWork = noOfDayWork;
	this.salaryPerDay = salaryPerDay;
}
public int getNoOfDayWork() {
	return noOfDayWork;
}
public void setNoOfDayWork(int noOfDayWork) {
	this.noOfDayWork = noOfDayWork;
}
public double getSalaryPerDay() {
	return salaryPerDay;
}
public void setSalaryPerDay(double salaryPerDay) {
	this.salaryPerDay = salaryPerDay;
}
@Override
public String toString() {
	return "Salary [noOfDayWork=" + noOfDayWork + ", salaryPerDay=" + salaryPerDay + "]";
}

}
