package org.cap.maps;

import java.util.Scanner;

public class EmployeeMain {
public static void main(String args[]){
	int ch;
	String s;
	Scanner sc=new Scanner(System.in);
	do{
	System.out.println("Enter your choice \n 1.Create Employee Record \n 2.View Employee Record \n 3.Exit");
	ch=sc.nextInt();
	switch(ch){
	case 1:
		EmpInterImpl emip=new EmpInterImpl();
		Employee emp=emip.createEmployee();
		Salary sal=emip.createSalaryslip();
		Database database = new Database();
		database.yoyo(emp, sal);
		break;
	case 2:
		EmpInterImpl emip1=new EmpInterImpl();
		emip1.viewEmployee();
		break;
	case 3:
		System.exit(0);
	}
	System.out.println("Do you want to continue Y/N");
	 s=sc.next();
	}while(s.equalsIgnoreCase("y"));
}
}
