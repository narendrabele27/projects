package org.cap.maps;

import java.util.Date;

public class Employee {
int empid;
String firstname;
String lastname;
Date dob;
Date doj;
Employee(){
	
}
public Employee(int empid, String firstname, String lastname, Date dob, Date doj) {
	super();
	this.empid = empid;
	this.firstname = firstname;
	this.lastname = lastname;
	this.dob = dob;
	this.doj = doj;
}
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
public Date getDoj() {
	return doj;
}
public void setDoj(Date doj) {
	this.doj = doj;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + empid;
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Employee other = (Employee) obj;
	if (empid != other.empid)
		return false;
	return true;
}
@Override
public String toString() {
	return "Employee [empid=" + empid + ", firstname=" + firstname + ", lastname=" + lastname + ", dob=" + dob
			+ ", doj=" + doj + "]";
}



}
