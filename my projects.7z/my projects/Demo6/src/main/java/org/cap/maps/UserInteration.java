package org.cap.maps;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class UserInteration {
	int eid;
	String fname;
	String lname;
	Date dob;
	Date doj;
	int daywork;
	double salday;
	Scanner sc=new Scanner(System.in);
	SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
Employee getEmployeeDetails(){
	
	
	System.out.println("Enter Employee ID");
	eid=sc.nextInt();
	System.out.println("Enter Employee First Name");
	fname=sc.next();
	System.out.println("Enter Employee Last Name");
	lname=sc.next();
	System.out.println("Enter Employee Date of Birth in dd-mm-yyyy format");
	String sdob=sc.next();
	try {
		dob=sdf.parse(sdob);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("Enter Employee Date of joining in dd-mm-yyyy format");
	String sdoj=sc.next();
	try {
		doj=sdf.parse(sdoj);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	Employee em=new Employee(eid, fname, lname, dob, doj);
	return em;
}
Salary getSalaryDetails(){
	System.out.println("Enter Number of days worked");
	daywork=sc.nextInt();
	System.out.println("Enter salary per day");
	salday=sc.nextDouble();
	Salary sal=new Salary(daywork, salday);
	return sal;
}
/*void PrintEmployeeDetails(){
	System.out.println("Employee id is "+eid);
	System.out.println("Employee First Name is "+fname);
	System.out.println("Employee Last Name is "+lname);
	String sdob=sdf.format(dob);
	System.out.println("Employee Date of Birth is "+sdob);
	String sdoj=sdf.format(doj);
	System.out.println("Employee Date of Joining is "+sdoj);
	
}*/
}
