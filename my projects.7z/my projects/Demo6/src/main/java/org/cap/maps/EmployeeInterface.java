package org.cap.maps;

public interface EmployeeInterface {
Employee createEmployee();
Salary createSalaryslip();
void viewEmployee();
}
