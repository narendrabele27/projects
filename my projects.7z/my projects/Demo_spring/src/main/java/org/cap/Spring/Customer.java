package org.cap.Spring;

public class Customer {
	private int custID;
	private String CustName;
	private String custType;
	private String contactNo;
	
	
	public Customer(){}
	
	
	public Customer(int custID, String custName, String custType, String contactNo) {
		super();
		this.custID = custID;
		CustName = custName;
		this.custType = custType;
		this.contactNo = contactNo;
	}
	public int getCustID() {
		return custID;
	}
	public void setCustID(int custID) {
		this.custID = custID;
	}
	public String getCustName() {
		return CustName;
	}
	public void setCustName(String custName) {
		CustName = custName;
	}
	public String getCustType() {
		return custType;
	}
	public void setCustType(String custType) {
		this.custType = custType;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	@Override
	public String toString() {
		return "Customer [custID=" + custID + ", CustName=" + CustName + ", custType=" + custType + ", contactNo="
				+ contactNo + "]";
	}
	
	
	

}
