package org.cap.Spring;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class MainClass {

	public static void main(String[] args) {
		//ApplicationContext context=new ClassPathXmlApplicationContext("mybean.xml");
		XmlBeanFactory context=new XmlBeanFactory(new ClassPathResource("mybean.xml"));
		Customer customer=(Customer)context.getBean("cust");
		System.out.println(customer);

	}

}
