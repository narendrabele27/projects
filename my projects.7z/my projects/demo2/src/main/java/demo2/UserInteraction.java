package demo2;

import java.util.Date;
import java.util.Scanner;





public class UserInteraction {
public Employee getEmployee(){
		
		Employee employee=new Employee();
		int employeeId;
		boolean flag=false;
		String eid,empKinId,firstName,lastName,age,salary,email;
		Scanner sc=new Scanner(System.in);
		
		
		//Validate Employee Id
		do{
		System.out.println("Enter Employee Id:");
		eid=sc.next();
		flag=Validate.isValidEmployeeId(eid);
			if(!flag)
				System.out.println("Invalid EmployeeId! ID should be 5 digit!");
		
		}while(!flag);

		employee.setEmpId(Integer.parseInt(eid));
		
		
				//Validate Employee KinId
				do{
				System.out.println("Enter Employee KinId:");
				empKinId=sc.next();
				flag=Validate.isValidKinId(empKinId);
					if(!flag)
						System.out.println("Invalid KinId!");
				
				}while(!flag);

				employee.setKinID(empKinId);
				
				
				do{
					System.out.println("Enter Employee First Name:");
					firstName=sc.next();
					flag=Validate.isValidFirstName(firstName);
						if(!flag)
							System.out.println("Invalid FirstName");
					
					}while(!flag);

					employee.setFirstName(firstName);
					
					do{
						System.out.println("Enter Employee Last Name:");
						lastName=sc.next();
						flag=Validate.isValidLastName(lastName);
							if(!flag)
								System.out.println("Invalid LastName");
						
						}while(!flag);

						employee.setLastName(lastName);
						
						do{
							System.out.println("Enter Employee Age:");
							age=sc.next();
							flag=Validate.isValidAge(age);
								if(!flag)
									System.out.println("Invalid Age");
							
							}while(!flag);

							employee.setAge(age);
							
							do{
								System.out.println("Enter Employee Salary:");
								salary=sc.next();
								flag=Validate.isValidSalary(age);
									if(!flag)
										System.out.println("Invalid Salary");
								
								}while(!flag);

								employee.setSalary(Float.parseFloat(salary));
								
								
								
								System.out.println("Enter Date of Birth:");
								employee.setEmpDOB(getDateValue());
								
								System.out.println("Enter Date of Joining:");
								employee.setEmpDOJ(getDateValue());
					
								
								
								do{
									System.out.println("Enter Employee Email ID :");
									email=sc.next();
									flag=Validate.isValidEmailID(email);
										if(!flag)
											System.out.println("Invalid Email");
									
									}while(!flag);

									employee.setEmail(email);
					
					 return employee;		
}



	public Date getDateValue(){
	String empDob;
	Scanner sc=new Scanner(System.in);
	boolean flag=false;
	
	do{
	
	empDob=sc.next();
	flag=Validate.isValidEmpDob(empDob);
		if(!flag)
			System.out.println("Invalid Date Format! (dd-MMM-yyyy)");
	
	}while(!flag);
	
	
	Date empdb=new Date(empDob);
	
	return empdb;
}
 
}
