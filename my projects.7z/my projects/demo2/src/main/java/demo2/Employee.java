package demo2;

import java.util.*;

public class Employee {
int empId;
String kinID;
String firstName;
String lastName;
String age;
double salary;
Date empDOB;
Date empDOJ;
String address;
String email;
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getKinID() {
	return kinID;
}
public void setKinID(String kinID) {
	this.kinID = kinID;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public Date getEmpDOB() {
	return empDOB;
}
public void setEmpDOB(Date date) {
	this.empDOB = date;
}
public Date getEmpDOJ() {
	return empDOJ;
}
public void setEmpDOJ(Date date) {
	this.empDOJ = date;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}

}
