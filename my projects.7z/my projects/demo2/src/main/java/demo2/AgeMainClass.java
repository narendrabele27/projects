package demo2;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;
import java.util.StringTokenizer;

public class AgeMainClass {
	public static void main(String [] args)
	{
		Scanner console=new Scanner(System.in);
		Calendar cal = new GregorianCalendar();  //create Calendar instance
		int day,mon,year,h,m,s;
		cal.clear();
		System.out.println("Enter a date of birth in particular format (dd/mm/yyyy-hh:mm:ss): ");
		String s1=console.next();
		StringTokenizer tokens = new StringTokenizer(s1, ":-/");  //Use StringTokenizer to split one string in different tokens
		try{
			day=Integer.parseInt(tokens.nextToken());
			mon=Integer.parseInt(tokens.nextToken());
			mon--;
			year=Integer.parseInt(tokens.nextToken());
			h=Integer.parseInt(tokens.nextToken());
			m=Integer.parseInt(tokens.nextToken());
			s=Integer.parseInt(tokens.nextToken());
			cal.set(year,mon,day,h,m,s);
			//CalculatingAge ca=new CalculatingAge();
			CalculatingAge.FindAge(cal);//call FindAge method
		}
		catch(Exception e) //catch if any error occur
		{
			e.printStackTrace();
			System.out.println("\n******Date Not Entered In Correct Format******");
		}
	}//end main method

}
