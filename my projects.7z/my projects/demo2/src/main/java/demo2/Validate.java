package demo2;

public class Validate {
	public static boolean isValidEmployeeId(String empId){
		return empId.matches("\\d{5}");
	}
	
	public static boolean isValidKinId(String kinid){
		return kinid.matches("\\d{5}_(FS|TS|IN|fs|ts|in)");
	}
	public static boolean isValidFirstName(String firstName){
		return firstName.matches("[A-Z][a-z]*");
	}
	public static boolean isValidLastName(String lastName){
		return lastName.matches("[A-Z][a-z]*");
		
	}
	public static boolean isValidAge(String age){
		return age.matches("(1[8-9]|2[0-9]|3[0-9]|4[0-9]|5[0-9]|6[0-9]|7[0-9]|8[0-9]|9[0-9])");
	}
	public static boolean isValidSalary(String salary){
		return salary.matches("(2[0[0[0-9]-9]-9]|3[0[0[0-9]-9]-9]|4[0[0[0-9]-9]-9]|5[0[0[0-9]-9]-9]|"
				+ "6[0[0[0-9]-9]-9]|7[0[0[0-9]-9]-9]|8[0[0[0-9]-9]-9]|9[0[0[0-9]-9]-9]|1[0[0[0[0-9]-9]-9]-9]|"
				+ "2[0[0[0[0-9]-9]-9]-9]|3[0[0[0[0-9]-9]-9]-9]|4[0[0[0[0-9]-9]-9]-9]|5[0[0[0[0-9]-9]-9]-9]|6[0[0[0[0-9]-9]-9]-9]|"
				+ "7[0[0[0[0-9]-9]-9]-9]|8[0[0[0[0-9]-9]-9]-9]|9[0[0[0[0-9]-9]-9]-9]|1[0[0[0[0[0-9]-9]-9]-9]-9])");
	
	}
	public static boolean isValidEmpDob(String empDob){
		return empDob.matches("[0-3][0-9]-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-"
				+ "[12][7890]\\d{2}");
	}
	public static boolean isValidAdddress(String address){
		return address.matches("\\W&[0-9]&[#|.|,|/]");
	}
	public static boolean isValidEmailID(String email){
		return email.matches("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
	}
}
