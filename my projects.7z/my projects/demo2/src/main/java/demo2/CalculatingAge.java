package demo2;

import java.util.Calendar;

public class CalculatingAge {
	 public static void FindAge(Calendar birthDay)
		{
			int years = 0;
	 		int months = 0;
		  	int days = 0;	
			int hour=0;
			int min=0;
			int sec=0;
	 
			 //create calendar object for current day
	  		Calendar currentDay = Calendar.getInstance();
			//Get difference between years
		  	years = currentDay.get(Calendar.YEAR) - birthDay.get(Calendar.YEAR);
			int currMonth = currentDay.get(Calendar.MONTH)+1;
			int birthMonth = birthDay.get(Calendar.MONTH)+1;
	  	  	//Get difference between months
			months = currMonth - birthMonth;
	 
	  		//if month difference is in negative then reduce years by one and calculate the number of months. 
	 		 if(months < 0)
		  	{
	  			 years--;
	   			months = 12 - birthMonth + currMonth;
	 
	  			 if(currentDay.get(Calendar.DATE)<birthDay.get(Calendar.DATE))
	    				months--;
	 
	  		}
			else if(months == 0 && currentDay.get(Calendar.DATE) < birthDay.get(Calendar.DATE))
			{
	  			 years--;
	   			months = 11;
	  		}
	 
	 
	  		//Calculate the days
	  		if(currentDay.get(Calendar.DATE)>birthDay.get(Calendar.DATE))
	   			days = currentDay.get(Calendar.DATE) -  birthDay.get(Calendar.DATE);
			else if(currentDay.get(Calendar.DATE)<birthDay.get(Calendar.DATE))
			{
	   			int today = currentDay.get(Calendar.DAY_OF_MONTH); 
	   			currentDay.add(Calendar.MONTH, -1);
	   			days = currentDay.getActualMaximum(Calendar.DAY_OF_MONTH)-birthDay.get(Calendar.DAY_OF_MONTH)+today;
	  		}
			else
			{
	   			days=0;
			      	if(months == 12)
				{
	    				years++;
				    	months = 0;
	   			}
	  		}
			hour=currentDay.get(Calendar.HOUR_OF_DAY)-birthDay.get(Calendar.HOUR_OF_DAY);
			if(hour < 0)
			{
				days--;
				hour+=24;
			}
			min=currentDay.get(Calendar.MINUTE)-birthDay.get(Calendar.MINUTE);
			if(min < 0)
			{
				hour--;
				if(hour<0)
				{
					days--;
					hour+=24;
				}
				min+=60;
			}
			sec=currentDay.get(Calendar.SECOND)-birthDay.get(Calendar.SECOND);
	  		if(sec < 0)
			{
				min--;
				if(min<0)
				{
					hour--;
					min+=60;
					if(hour<0)
					{
						days--;
						hour+=24;
					}
				}
				sec+=60;
			}
	 
	 	 	System.out.println("The age is : "+years+" years, "+months+" months,  "+days+" days, "+ hour +" hours, " + min +" min and " +sec +" seconds.");
		}//end  method

}
