package org.cap.excaption;

public class ArrayMain {

	public static void main(String[] args) {
		ArrayException a=new ArrayException();
		a.accessElement();
		System.out.println("Rest of the code Executing");

	}

}
