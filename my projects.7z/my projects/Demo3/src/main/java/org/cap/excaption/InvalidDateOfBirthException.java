package org.cap.excaption;

public class InvalidDateOfBirthException extends Exception {

	public InvalidDateOfBirthException(String message) {
		super(message);
		
	}
	

}
