package org.cap.excaption;

public class DepositeAmountException extends Exception {

	public DepositeAmountException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
