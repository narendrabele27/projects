package org.cap.excaption;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.CLASS)
public @interface Book {
String BookName();
String AuthorName();
String Publisher() default "Tata Mac";
String BookType();


}
