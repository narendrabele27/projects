package org.cap.excaption;


import java.util.Scanner;

public class MainClass {
public static void main(String args[]){
	double salary;
	String dob;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the Salary of the Employee:");
	salary=sc.nextDouble();
	if(salary>=2000 && salary<=500000){
		System.out.println("Valid Salary is Entered");
	}
	else {
		try{
		throw new InvalidSalaryException("Enter Valid Salry Amount");
	}catch(InvalidSalaryException e){
		System.out.println("Error Massage:"+e.getMessage());
	}
	}	
	
	System.out.println("Enter Employee Date of Birth in format dd-mm-yyyy");
     dob=sc.next();
	System.out.println("");
}
}
