package org.cap.excaption;

public class Demo {
int num1=10,num2=10,num3;
@Book(BookName="Java",AuthorName="Tom",BookType="Technical")
void calculate(){
	num3=num1+num2;
}
}
