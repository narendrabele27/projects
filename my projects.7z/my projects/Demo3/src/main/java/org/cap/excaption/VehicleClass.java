package org.cap.excaption;

import java.util.Scanner;

public class VehicleClass {
	
	void checkcollision(){
		System.out.println("In which direction the two vehicle are moving \n 1.Same Direction \n2.Opposite Direction");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		switch(choice){
		case 1:
			System.out.println("No Collision will take place \n !!!! Happy Journey !!!!");
			break;
		case 2:
			try{
				
			}
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*int arr[]=new int[5];
int veh1[]={1,2,3,4,5};
int veh2[]={1,2,3,4,5};
void collision(){
for (int i=0,j=arr.length-1;i<arr.length;i++,j--){
	if(veh1[i]==veh2[j]){
		try{
			throw new VehicleException("Collision will take place please change the route");
		}catch(VehicleException v){
			System.out.println("Error message :"+v.getMessage());
		}catch(NullPointerException n){
			System.out.println(n.getMessage());
		}
	}
}
}*/
}
