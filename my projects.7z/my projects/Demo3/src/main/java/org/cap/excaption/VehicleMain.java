package org.cap.excaption;

public class VehicleMain {
public static void main(String args[]){
	VehicleClass vd =new VehicleClass();
	vd.collision();
	
}
}





