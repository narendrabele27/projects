package org.cap.excaption;

public class VehicleException extends Exception {

	public VehicleException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
