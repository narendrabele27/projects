package org.cap.excaption;

import java.util.Scanner;

public class AssertionDemo {
public static void main(String args[]){
	double bonus;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Bonus amount");
	bonus=sc.nextDouble();
	assert bonus>500:"Bonus should be greater than 500";
	System.out.println(bonus);
	}
}
