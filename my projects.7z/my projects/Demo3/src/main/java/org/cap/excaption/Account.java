package org.cap.excaption;

import java.util.Scanner;

public class Account {
int accountID;
String accountName;
String openingdate;
double depositeAmount;
String accountType;
String sav="saving";
String cur="current";
String sal="salary";
void enterDetails(){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Account ID");
	accountID=sc.nextInt();
	System.out.println("Enter Account name");
	accountName=sc.next();
	System.out.println("Enter opening datre of Account");
	openingdate=sc.next();
	System.out.println("Enter Account type");
	accountType=sc.next();
	System.out.println("Enter deposite amount");
	depositeAmount=sc.nextDouble();
	if (accountType.equals(sav) && depositeAmount<=1000){
		try{
			throw new DepositeAmountException("Deposite Amount for Saving account should be greater than 1000");
		}catch(DepositeAmountException d){
			System.out.println("Error:"+d.getMessage());
			System.exit(0);
		}
	}else if (accountType.equals(cur) && depositeAmount<=5000){
		try{
			throw new DepositeAmountException("Deposite Amount for current Account should be greater than 5000");
		}catch(DepositeAmountException d){
			System.out.println("Error:"+d.getMessage());
			System.exit(0);
		}
	}else if (accountType.equals(sal) && depositeAmount<0){
		try{
			throw new DepositeAmountException("Deposite Amount for salary Account should be greater than or equal to 0");
		}catch(DepositeAmountException d){
			System.out.println("Error :"+d.getMessage());
			System.exit(0);
		}
	}
}
void printDetails(){
	System.out.println("Account ID is "+accountID);
	System.out.println("Account Name is "+accountName);
	System.out.println("Account Opening date is "+openingdate);
	System.out.println("Deposite amount is "+depositeAmount);
	System.out.println("Account Type is "+accountType);
}

}
