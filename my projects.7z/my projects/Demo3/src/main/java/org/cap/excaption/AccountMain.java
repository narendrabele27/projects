package org.cap.excaption;

public class AccountMain {

	public static void main(String[] args) {
		Account a=new Account();
		a.enterDetails();
		//a.checkDepositeAmount();
		a.printDetails();
		

	}

}
