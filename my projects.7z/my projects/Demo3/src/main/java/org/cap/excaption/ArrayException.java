package org.cap.excaption;

public class ArrayException {
int rollno[]={1,2,3,4,5,6,7,8,9,10};
String name[]={"tom","jerry","hitesh","Shoaib","kishor","suyog","shrikant","Ram","Nihal","Pranit"};
void accessElement(){
	System.out.println("Roll number is "+rollno[0]+"and Name is "+name[0]);
	System.out.println("Trying to access 10 element of array");
	try{
	System.out.println("Roll number is "+rollno[10]+"and Name is "+name[10]);
	}catch(ArrayIndexOutOfBoundsException e){
		System.out.println("Error message: "+e.getMessage());
	}
}
}
