package org.cap.relation;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class MainClass {
	public static void main(){
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Product.class);
		config.addAnnotatedClass(Category.class);
		config.addAnnotatedClass(Subcategory.class);
		config.addAnnotatedClass(Supplier.class);
		config.addAnnotatedClass(Discount.class);
		config.configure();
		new SchemaExport(config).create(true, true);
		SessionFactory sessionFactory=config.buildSessionFactory();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		//Product product=new Product(1, "Sony", "Mobile", new Date(), new Date(), 15000, "Electronics", "Mobile", "Tom", discounts, quantity, rating);
		
	}

}
