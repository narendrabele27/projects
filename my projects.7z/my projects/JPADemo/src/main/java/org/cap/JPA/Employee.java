package org.cap.JPA;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="Employee_Info")
public class Employee {
	@Id
	@GeneratedValue
	private int empId;
	@Column(nullable=false)
	private String firstName;
	private String lastName;
	@Column(columnDefinition="Decimal(10,2) default '100.00'")
	private double salary;
	@Temporal(TemporalType.DATE)
	private Date dob;
	@Temporal(TemporalType.TIMESTAMP)
	private Date doj;
	@Column(nullable=false)
	private String Email;
	
	
	
	public Employee(){}
	
	
	
	public Employee(int empId, String firstName, String lastName, double salary, Date dob, Date doj, String email) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.dob = dob;
		this.doj = doj;
		Email = email;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}



	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", dob=" + dob + ", doj=" + doj + ", Email=" + Email + "]";
	}
	
	
	
	
	

}
