package org.cap.relation;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Category {
	@Id
	private int category_Id;
	private String category_Name;
	private String description;
	@OneToMany(targetEntity=Product.class,mappedBy="category",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Product> products;
	
	public Category(){
		
	}



	public Category(int category_Id, String category_Name, String description) {
		super();
		this.category_Id = category_Id;
		this.category_Name = category_Name;
		this.description = description;
	}



	public int getCategory_Id() {
		return category_Id;
	}



	public void setCategory_Id(int category_Id) {
		this.category_Id = category_Id;
	}



	public String getCategory_Name() {
		return category_Name;
	}



	public void setCategory_Name(String category_Name) {
		this.category_Name = category_Name;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	@Override
	public String toString() {
		return "Category [category_Id=" + category_Id + ", category_Name=" + category_Name + ", description=" + description
				+ "]";
	}
	

}
