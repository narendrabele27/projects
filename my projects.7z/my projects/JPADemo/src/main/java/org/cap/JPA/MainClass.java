package org.cap.JPA;

import java.util.Date;
import java.util.Scanner;

import javax.transaction.Transaction;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.classic.Session;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class MainClass {

	public static void main(String[] args) {
		int empid;
		String firstName;
		String LastName;
		double salary;
		Date dob;
		Date doj;
		String email;
		int option;
		AnnotationConfiguration config=null;
		
	
		
		SessionFactory sessionFact=null;
		Session session=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("1. Create \n 2. Read \n 3. Delete \n 4.Update \n 5. ListAll \n 6. Exit ");
		option=sc.nextInt();
		switch(option){
		case 1: 
			System.out.println("Enter Employee Id ");
			empid=sc.nextInt();
			System.out.println("Enter Employee firstName");
			firstName=sc.next();
			System.out.println("Enter Employee lastname");
			LastName=sc.next();
			System.out.println("Enter Employee salary");
			salary=sc.nextDouble();
			System.out.println("Enter Employee Date of birth");
			String Dob=sc.next();
			dob=new Date(Dob);
			System.out.println("Enter Employee Date of joining");
			String Doj=sc.next();
			doj=new Date(Doj);
			System.out.println("Enter Employee Email Id");
			email=sc.next();
			config=new AnnotationConfiguration();
			config.addAnnotatedClass(Employee.class);
			config.configure();
			new SchemaExport(config).create(true, true);
			 sessionFact=config.buildSessionFactory();
			 session=sessionFact.openSession();
			 org.hibernate.Transaction trans=session.beginTransaction();
				Employee employee=new Employee(empid, firstName, LastName, salary, new Date(dob.getTime()), new Date(doj.getTime()), email);
				session.save(employee);
				trans.commit();
				
				session.close();
				break;
		case 2:
			System.out.println("Enter Employee Id");
			empid=sc.nextInt();
			config=new AnnotationConfiguration();
			config.addAnnotatedClass(Employee.class);
			config.configure();
			sessionFact=config.buildSessionFactory();
			session=sessionFact.openSession();
			org.hibernate.Transaction transaction=session.beginTransaction();
			Employee emp=(Employee)session.get(Employee.class, empid);
			session.save(emp);
			System.out.println(emp);
			transaction.commit();
			session.close();
			break;
			
		case 3:
			System.out.println("Enter Employee Id for delete");
			empid=sc.nextInt();
			config=new AnnotationConfiguration();
			config.addAnnotatedClass(Employee.class);
			config.configure();
			sessionFact=config.buildSessionFactory();
			session=sessionFact.openSession();
			org.hibernate.Transaction transaction1=session.beginTransaction();
			Employee emp1=(Employee)session.get(Employee.class, empid);
			session.delete(emp1);
			transaction1.commit();
			session.close();
			break;
		case 4:
			
		}
		
		
		
		
		
		
	 
		
		

	}

}
