package org.cap.relation;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Subcategory {
	@Id
	private int subCategory_Id;
	private String subCategory_Name;
	
	private Category category;
	@OneToMany(targetEntity=Product.class,mappedBy="subCategory",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Product> products;
	public Subcategory(){
		
	}

	public Subcategory(int subCategory_Id, String subCategory_Name, Category category) {
		super();
		this.subCategory_Id = subCategory_Id;
		this.subCategory_Name = subCategory_Name;
		this.category = category;
	}

	public int getSubCategory_Id() {
		return subCategory_Id;
	}

	public void setSubCategory_Id(int subCategory_Id) {
		this.subCategory_Id = subCategory_Id;
	}

	public String getSubCategory_Name() {
		return subCategory_Name;
	}

	public void setSubCategory_Name(String subCategory_Name) {
		this.subCategory_Name = subCategory_Name;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "SubCategory [subCategory_Id=" + subCategory_Id + ", subCategory_Name=" + subCategory_Name + ", category="
				+ category + "]";
	}

}
