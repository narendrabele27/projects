package org.cap.relation;

import java.util.Date;
import java.util.List;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class Discount {
	private int discount_Id;
	private String discount_Name;
	private String discription;
	private double discount_percentage;
	private Date valid_through;
	@ManyToOne
	@JoinColumn(name="product_Id")
	private List<Product> products;

	public Discount(){
		
	}

	public Discount(int discount_Id, String discount_Name, String discription, double discount_percentage,
			Date valid_through) {
		super();
		this.discount_Id = discount_Id;
		this.discount_Name = discount_Name;
		this.discription = discription;
		this.discount_percentage = discount_percentage;
		this.valid_through = valid_through;
	}

	public int getDiscount_Id() {
		return discount_Id;
	}

	public void setDiscount_Id(int discount_Id) {
		this.discount_Id = discount_Id;
	}

	public String getDiscount_Name() {
		return discount_Name;
	}

	public void setDiscount_Name(String discount_Name) {
		this.discount_Name = discount_Name;
	}

	public String getDiscription() {
		return discription;
	}

	public void setDiscription(String discription) {
		this.discription = discription;
	}

	public double getDiscount_percentage() {
		return discount_percentage;
	}

	public void setDiscount_percentage(double discount_percentage) {
		this.discount_percentage = discount_percentage;
	}

	public Date getValid_through() {
		return valid_through;
	}

	public void setValid_through(Date valid_through) {
		this.valid_through = valid_through;
	}

	@Override
	public String toString() {
		return "Discount [discount_Id=" + discount_Id + ", discount_Name=" + discount_Name + ", discription=" + discription
				+ ", discount_percentage=" + discount_percentage + ", valid_through=" + valid_through + "]";
	}

}
