package org.capgemini.io;

import java.util.Scanner;

public class UserInteraction {
public  Account getAccountDetails(){
	int accno;
	String accname;
	String acctype;
	String opendt;
	double amt;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Account number");
	accno=sc.nextInt();
	System.out.println("Enter Account name");
	accname=sc.next();
	System.out.println("Enter Account type");
	acctype=sc.next();
	System.out.println("Enter Account opening date");
	opendt=sc.next();
	System.out.println("Enter amount ");
	amt=sc.nextDouble();
	return new Account (accno, accname, acctype, opendt, amt);
}
}
