package org.capgemini.io;



public interface AccountDAO {
	public void createAccount(Account aac);
	//public Account readAccount(int accno);
}
