package org.capgemini.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Reverse {

	public static void main(String[] args) {
		File file=new File("D:\\Users\\NABELE\\My_Workspace\\Demo4\\src\\main\\resources\\sample.txt");
		FileReader fread=null;
		FileWriter fwrite=null;
		char[] c;
		int j=0;
		long fsize=file.length();
		try {
			fread=new FileReader(file);
			
			System.out.println("Before reversing the content of file");
			while(fsize>0){
				int ch=fread.read();
				System.out.print((char)ch);
				fsize--;
			}
			fread.close();
			System.out.println("\nAfter reversing the content of file");
			char ch[] = new char[(int)file.length()];
			for(int i=0;i<=file.length();i++){
				fread = new FileReader(file);
			fread.read(ch);
			}
			String str= new String(ch);
			char ch1[]=str.toCharArray();
			for(int i=ch1.length-1;i>=0;i--){
				System.out.print(ch1[i]);
			}
			
			
			/*long temp;
			for(long i=file.length()-1;i>=0;i--){
				
				int ch1=fread.read();
				System.out.print((char)ch1);
			}*/
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*finally{
			try {
				fread.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		*/

	}

}
