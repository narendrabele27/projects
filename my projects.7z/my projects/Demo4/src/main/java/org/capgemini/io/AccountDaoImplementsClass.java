package org.capgemini.io;

public class AccountDaoImplementsClass implements AccountDAO{

	public void createAccount(Account aac) {
	UserInteraction ui=new UserInteraction();
	ui.getAccountDetails();
		
	}

	/*public Account readAccount(int accno) {
		// TODO Auto-generated method stub
		return null;
	}*/

}
