package org.capgemini.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Copy {
public static void main(String args[]){
	File file=new File("D:\\Users\\NABELE\\My_Workspace\\Demo4\\src\\main\\resources\\one.txt");
	File file1=new File("D:\\Users\\NABELE\\My_Workspace\\Demo4\\src\\main\\resources\\two.txt");
	FileReader fread=null;
	FileWriter fwrite=null;
	long fsize=file.length();
	try {
		fread=new FileReader(file);
		System.out.println("Reading the data from:"+file.getName());
		while(fsize>0){
		int ch=fread.read();
		System.out.print((char)ch);
		fsize--;
		}
		fread.close();
		char ch[] = new char[(int)file.length()];
		for(int i=0;i<=file.length();i++){
			fread = new FileReader(file);
		fread.read(ch);
		}
		String str= new String(ch);
		fwrite=new FileWriter(file1);
		fwrite.write(str);
		fwrite.close();
		fread=new FileReader(file);
		System.out.println("\nReading the data from:"+file1.getName());
		long fsiz=file1.length();
		while(fsiz>0){
		int ch1=fread.read();
		System.out.print((char)ch1);
		fsiz--;
		}
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
