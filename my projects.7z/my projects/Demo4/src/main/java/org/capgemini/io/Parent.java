package org.capgemini.io;

public class Parent {
 long m1(){
	System.out.println("parent class");
	return 0;
}
}

