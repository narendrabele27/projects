package org.capgemini.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Occurance {

	public static void main(String[] args) {
		File file=new File("D:\\Users\\NABELE\\My_Workspace\\Demo4\\src\\main\\resources\\vowel.txt");
		FileReader fread=null;
		int counta=0;
		int counte=0;
		int counti=0;
		int counto=0;
		int countu=0;
		int count=0;
		try {
			
			char ch[] = new char[(int)file.length()];
			for(int i=0;i<=file.length();i++){
				fread = new FileReader(file);
			fread.read(ch);
			String str= new String(ch);
			char ch1[]=str.toCharArray();
			for(int j=0;i<file.length();i++){
				if(ch1[i]=='a'){
					counta++;
				}
				else if(ch1[i]=='e'){
					counte++;
				}
				else if(ch1[i]=='i'){
					counti++;
					
				}
				else if (ch1[i]=='o'){
					counto++;
					
				}
				else if (ch1[i]=='u'){
					countu++;
				}
			}
			}
			System.out.println("Number of a occurance is : "+counta);
			System.out.println("Number of e occurance is : "+counte);
			System.out.println("Number of i occurance is : "+counti);
			System.out.println("Number of o occurance is : "+counto);
			System.out.println("Number of u occurance is : "+countu);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
