package org.capgemini.io;

public class Child extends Parent {
protected long   m1(){
return 0;
}
}
