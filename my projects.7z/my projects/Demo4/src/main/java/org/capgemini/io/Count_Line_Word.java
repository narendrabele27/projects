package org.capgemini.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Count_Line_Word {
public static void main(String args[]){
	File file =new File("D:\\Users\\NABELE\\My_Workspace\\Demo4\\src\\main\\resources\\count.txt");
	FileReader fread=null;
	long fsize=file.length();
	int word=0,line=1;
	
	//System.out.println(fsize);
	try {
		
		char ch[] = new char[(int)file.length()];
		for(int i=0;i<=file.length();i++){
			fread = new FileReader(file);
		fread.read(ch);
		}
		String str= new String(ch);
		String temp=str;
		String str1[]=str.split(" |\n");
		int len=str1.length;
		
		System.out.println("Number of words are:"+len);
		//System.out.println("Number of words are"+word);
		//System.out.println("Number of lines are"+line);
		String str2[]=temp.split("\n");
		int lin=str2.length;
		System.out.println("Number of lines are:"+lin);
			fread.close();
			
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
