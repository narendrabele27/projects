package org.capgemini.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class BootClass {
public static void main(String args[]){
	File file=new File("D:\\Users\\NABELE\\My_Workspace\\Demo4\\src\\main\\resources\\account.dat");
	FileOutputStream fout=null;
	ObjectOutputStream out=null;
	Account acc=new Account();
	AccountDaoImplementsClass ad=new AccountDaoImplementsClass();
	try {
		fout=new FileOutputStream(file);
		out=new ObjectOutputStream(fout);
		ad.createAccount(acc);
		out.writeObject(acc);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try {
			out.close();
			fout.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
}
