package org.capgemini.io;

import java.io.Serializable;

public class Account implements Serializable{
int accountno;
String accountname;
String accountType;
String opendate;
double ammount;

public Account() {
	
}



public Account(int accountno, String accountname, String accountType, String opendate, double ammount) {
	super();
	this.accountno = accountno;
	this.accountname = accountname;
	this.accountType = accountType;
	this.opendate = opendate;
	this.ammount = ammount;
}



public int getAccountno() {
	return accountno;
}

public void setAccountno(int accountno) {
	this.accountno = accountno;
}

public String getAccountname() {
	return accountname;
}

public void setAccountname(String accountname) {
	this.accountname = accountname;
}

public String getAccountType() {
	return accountType;
}

public void setAccountType(String accountType) {
	this.accountType = accountType;
}

public String getOpendate() {
	return opendate;
}

public void setOpendate(String opendate) {
	this.opendate = opendate;
}

public double getAmmount() {
	return ammount;
}

public void setAmmount(double ammount) {
	this.ammount = ammount;
}



@Override
public String toString() {
	return "Account [accountno=" + accountno + ", accountname=" + accountname + ", accountType=" + accountType
			+ ", opendate=" + opendate + ", ammount=" + ammount + "]";
}

}
