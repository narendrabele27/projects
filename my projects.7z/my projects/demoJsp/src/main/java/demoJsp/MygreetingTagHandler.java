package demoJsp;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class MygreetingTagHandler extends SimpleTagSupport {
	
	private String msg;
	
	

	public void setName(String msg) {
		this.msg = msg;
	}



	@Override
	public void doTag() throws JspException, IOException {
		JspWriter out=getJspContext().getOut();
		
		StringWriter str=new StringWriter();
		getJspBody().invoke(str);
		out.println(msg+","+str);
	
	}
	

}
