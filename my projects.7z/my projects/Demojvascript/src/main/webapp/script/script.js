/*var objBold;
var objItalics;
var mytxt=document.getElementById('cntDiv').textContent;

function changeStyle(){
	var objBold=myForm.chkBold.checked;
	
	if(objBold)
		document.getElementById('cntDiv').innerHTML="<b>"+mytxt+"</b>";
	else
		document.getElementById('cntDiv').innerHTML=mytxt;
}

function changeItalics(){
	var objItalics=myForm.chkItalics.checked;
	alert(objBold);
	alert(objItalics);
	if(objBold){
		if(objItalics)
			document.getElementById('cntDiv').innerHTML="<i><b>"+mytxt+"</b></i>";
		else
			document.getElementById('cntDiv').innerHTML="<b>"+mytxt+"</b>";
	}else
		document.getElementById('cntDiv').innerHTML=mytxt;
	}*/


function changeStyle(){
	var txtStyles=myForm.font;
	var mytxt=document.getElementById('cntDiv').textContent;

			if(txtStyles[0].checked &&
					txtStyles[1].checked &&
						txtStyles[2].checked)
				document.getElementById('cntDiv').innerHTML="<i><b><u>"+mytxt+"</u></b></i>";
			else if(txtStyles[0].checked &&
					txtStyles[1].checked)
				document.getElementById('cntDiv').innerHTML="<i><b>"+mytxt+"</b></i>";
			else if(txtStyles[0].checked)
				document.getElementById('cntDiv').innerHTML="<b>"+mytxt+"</b>";
			else
				document.getElementById('cntDiv').innerHTML=mytxt;
				
				
		
}

function changeColor(){
	//var mytxt=document.getElementById('cntDiv').innerHTML;
	
	//alert(mytxt);
	var selColor=myForm.txtColor.value;
	
	document.getElementById('cntDiv').style.color=selColor;
	
}

function changeFontFace(){
	var selFont=myForm.myFont.value;
	document.getElementById('cntDiv').style.fontFamily=selFont;
}













