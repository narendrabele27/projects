app.controller("mycontroller",function($scope,$http){
	var url="http://localhost:8080/Angular13june/pages/customerDetails";
	$http.get(url).success(function(response){
		$scope.customers=response;
	});
	
	
});