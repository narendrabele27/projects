package org.cap.collectiondemo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class DateDemo {
	public static void main(String args[]){
	Date dob=null;
	Scanner sc=new Scanner(System.in);
	SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
	System.out.println("Enter date of birth in dd-mm-yyyy format");
	String sdob=sc.next();
    try {
		 dob=sdf.parse(sdob);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    String sdob1=sdf.format(dob);
    System.out.println(sdob1);
	
	}

}
