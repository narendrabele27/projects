package org.cap.collectiondemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class MainAccount {
public static void main(String args[]){
	Address ad=new Address(12,"Gandi Road","Pune","Maharashtra");
	Address ad1=new Address(13,"Gandi Road","Chandrapur","Maharashtra");
	Address ad2=new Address(14,"Gandi Road","Chennai","Maharashtra");
	Address ad3=new Address(15,"Gandi Road","Nagpur","Maharashtra");
	Address ad4=new Address(16,"Gandi Road","Buldhana","Maharashtra");
	Address ad5=new Address(21,"Gandi Road","Wardha","Maharashtra");
	Address ad6=new Address(56,"Gandi Road","Warora","Maharashtra");
	Address ad7=new Address(67,"Gandi Road","Ghugus","Maharashtra");
	Address ad8=new Address(99,"Gandi Road","Thane","Maharashtra");
	Address ad9=new Address(54,"Gandi Road","Navi mumbai","Maharashtra");
	
	Account ac1=new Account(123,"Narendra Bele","saving",new Date(),100000,ad);
	Account ac2=new Account(125,"Suyog Dhokpande","saving",new Date(),100000,ad1);
	Account ac3=new Account(120,"Nihal Mahoture","saving",new Date(),100000,ad2);
	Account ac4=new Account(110,"Tom","saving",new Date(),100000,ad3);
	Account ac5=new Account(106,"Jerry","saving",new Date(),100000,ad4);
	Account ac6=new Account(143,"Sam","saving",new Date(),100000,ad5);
	Account ac7=new Account(112,"Shrikant","saving",new Date(),100000,ad6);
	Account ac8=new Account(182,"Shripal","saving",new Date(),100000,ad7);
	Account ac9=new Account(169,"Pranit","saving",new Date(),100000,ad8);
	Account ac10=new Account(155,"Pawan","saving",new Date(),100000,ad9);
	ArrayList<Account> accounts = new ArrayList<Account>();
	//HashSet<Account> accounts=new HashSet<Account>();
	ArrayList<Address> address=new ArrayList<Address>();
	accounts.add(ac1);
	accounts.add(ac2);
	accounts.add(ac3);
	accounts.add(ac4);
	accounts.add(ac5);
	accounts.add(ac6);
	accounts.add(ac7);
	accounts.add(ac8);
	accounts.add(ac9);
	accounts.add(ac10);
	Iterator<Account> it =accounts.iterator();
	while(it.hasNext())
		System.out.println(it.next());
	/*ArrayList<Account> lst=new ArrayList<Account>();
	for(Account acco:accounts)
		lst.add(acco);*/
	
	System.out.println("Enter your option");
	System.out.println("SORT");
	System.out.println("\t 1.By Account number");
	System.out.println("\t 2.By Account Name");
	System.out.println("\t 3.By City");
	Scanner sc =new Scanner(System.in);
	int ch=sc.nextInt();
	switch(ch){
	
	case 1:
		Collections.sort(accounts,new  ByAccountNumber());
		Iterator<Account> ita =accounts.iterator();
		while(ita.hasNext()){
			System.out.println(ita.next());
		}
		break;
	case 2:
		Collections.sort(accounts, new ByAccountName());
		Iterator<Account> itb=accounts.iterator();
		while(itb.hasNext()){
			System.out.println(itb.next());
		}
		break;
	case 3:
		Collections.sort(accounts,new  ByCity());
		Iterator<Account> itc=accounts.iterator();
		while(itc.hasNext()){
			System.out.println(itc.next());
			
		}
		break;
	}
	
}
}
