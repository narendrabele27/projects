package org.cap.collectiondemo;

import java.util.Comparator;

public class ByCity implements Comparator<Account> {

	public int compare(Account ad1, Account ad2) {
		if(ad1.getAdd().getCity().compareTo(ad2.getAdd().getCity())>0)
				return 1;
		else if(ad1.getAdd().getCity().compareTo(ad2.getAdd().getCity())<0)
			return -1;
		else return 0;
	}

}
