package org.cap.collectiondemo;

import java.util.ArrayList;
import java.util.ListIterator;

public class CollectioDemo {
	public static void main(String args[]){
		ArrayList<Integer> myList=new ArrayList<Integer>();
		myList.add(12);
		myList.add(22);
		myList.add(88);
		myList.add(114);
		myList.add(64);
		myList.add(76);
		myList.add(88);
		myList.add(136);
		System.out.println(myList);
		ListIterator<Integer> lstit=myList.listIterator();
		while(lstit.hasNext()){
			Integer num=lstit.next();
			System.out.print(num+" ");
			
			
		}
		
		/*myList.clear();
		System.out.println(myList);*/
		System.out.println("\n");
		/*Boolean b=myList.contains(22);
		System.out.println(b);*/
		/*myList.ensureCapacity(20);
		System.out.println(myList);*/
		
		//System.out.println(myList.get(3));
		//System.out.println(myList.indexOf(64));
		//System.out.println(myList.isEmpty());
		//System.out.println(myList.lastIndexOf(88));
		//System.out.println(myList.remove(3));
		//System.out.println(myList0);
		//System.out.println(myList.removeAll(myList));
		//System.out.println(myList);
		//myList.set(2, 66);
		System.out.println(myList.size());
		System.out.println(myList.subList(2, 5));
		myList.trimToSize();
		System.out.println(myList);
	}

}
