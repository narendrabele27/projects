package org.cap.collectiondemo;

import java.util.Comparator;

public class ByAccountName implements Comparator<Account>{

	public int compare(Account acc1, Account acc2) {
		if((acc1.getAccname()).compareTo(acc2.getAccname())>0)
			return 1;
		else if((acc1.getAccname()).compareTo(acc2.getAccname())<0)
			return -1;
		else return 0;
	}

}
