package org.cap.collectiondemo;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class MainClass {
public static void main(String args[]){
	Employee emp1=new Employee(11,"Narendra","Bele",20000);
	Employee emp2=new Employee(23,"Suyog","Dhokpande",20000);
	Employee emp3=new Employee(15,"Nihal","Mohuture",20000);
	Employee emp4=new Employee(65,"Shrikant","Mitakari",20000);
	Employee emp5=new Employee(72,"Shripal","jadhav",20000);
	Employee emp6=new Employee(15,"Nihal","Mohuture",20000);
	Employee emp7=new Employee(23,"Suyog","Dhokpande",20000);
	Employee emp8=new Employee(15,"Nihal","Mohuture",20000);
	Employee emp9=new Employee(23,"Suyog","Dhokpande",20000);
	//HashSet<Employee> employees=new HashSet<Employee>();
	TreeSet<Employee> employees=new TreeSet<Employee>();
	employees.add(emp1);
	employees.add(emp2);
	employees.add(emp3);
	employees.add(emp4);
	employees.add(emp5);
	employees.add(emp6);
	employees.add(emp7);
	employees.add(emp8);
	employees.add(emp9);
	Iterator<Employee> it =employees.iterator();
	while(it.hasNext())
		System.out.println(it.next());
}
}
