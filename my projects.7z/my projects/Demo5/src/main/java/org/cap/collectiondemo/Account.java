package org.cap.collectiondemo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Account {
int accno;
String accname;
String acctype;
Date date;
double sal;
Address add;
public Account(){
	
}
public Account(int accno, String accname, String acctype, Date date, double sal, Address add) {
	super();
	this.accno = accno;
	this.accname = accname;
	this.acctype = acctype;
	this.date = date;
	this.sal = sal;
	this.add = add;
}
public int getAccno() {
	return accno;
}
public void setAccno(int accno) {
	this.accno = accno;
}
public String getAccname() {
	return accname;
}
public void setAccname(String accname) {
	this.accname = accname;
}
public String getAcctype() {
	return acctype;
}
public void setAcctype(String acctype) {
	this.acctype = acctype;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
public double getSal() {
	return sal;
}
public void setSal(double sal) {
	this.sal = sal;
}
public Address getAdd() {
	return add;
}
public void setAdd(Address add) {
	this.add = add;
}
@Override
public String toString() {
	return "Account [accno=" + accno + ", accname=" + accname + ", acctype=" + acctype + ", date=" + date + ", sal="
			+ sal + ", add=" + add + "]";
}





}
