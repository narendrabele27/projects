package org.cap.collectiondemo;

import java.util.HashMap;
import java.util.Set;

public class DemoMap {
public static void main(String args[]){
	HashMap<Integer, String> map=new HashMap<Integer, String>();
	map.put(1, "Narendra");
	map.put(2, "Pranit");
	map.put(3, "Shripal");
	map.put(4, "Pawan");
	map.put(5, "Suyog");
	map.put(6, "Shrikant");
	//System.out.println(map.containsKey(2));
	//System.out.println(map.entrySet());
	//Set<Entry<Integer,String>> entries=map.entrySet();
	System.out.println(map);
}
}
