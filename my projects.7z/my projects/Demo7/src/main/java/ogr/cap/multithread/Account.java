package ogr.cap.multithread;

public class Account {
double bal=1000;

synchronized public void withdraw(double balance){
	if(this.bal<(balance+500)){
		System.out.println("Insufficient Balance in the account");
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	this.bal=this.bal-balance;
	System.out.println("After withdraw balance is "+ this.bal);
	
}

synchronized public void deposite(double balance){
	this.bal=this.bal+balance;
	System.out.println("After deposite balance is "+this.bal);
	notifyAll();
}



}
