package ogr.cap.multithread;

public class PrintWord  {
	 String str1="";
	
	
synchronized public void print(String str){
	for(int i=0;i<str.length();i++){
		str1=str1+str.charAt(i);
		System.out.println(str1);
	}
	
	
}
}
