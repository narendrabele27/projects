package ogr.cap.multithread;

import java.util.Scanner;

public class MultiplicationTable extends Thread{
	int num;
	public MultiplicationTable(int num){
		this.num=num;
	}
	public void run(){
		//System.out.println("Enter 5,10 or 15 to print there table");
		//Scanner sc=new Scanner(System.in);
		//num=sc.nextInt();
		for(int i=1;i<=10;i++)
			System.out.println(num +"* "+i+"= "+num*i);
	}

}
