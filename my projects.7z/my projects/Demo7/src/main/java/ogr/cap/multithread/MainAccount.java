package ogr.cap.multithread;

public class MainAccount {
public static void main(String agrs[]){
	final Account ac=new Account();
	Thread t1=new Thread(){
		public void run(){
			ac.withdraw(800);
		}
	};
	Thread t2=new Thread(){
		public void run(){
			ac.deposite(1000);
		}
	};
	Thread t3=new Thread(){
		public void run(){
			ac.withdraw(1200);
		}
	};
	t1.start();
	t2.start();
	t3.start();

}
}
