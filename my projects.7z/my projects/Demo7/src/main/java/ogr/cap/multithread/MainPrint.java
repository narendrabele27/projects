package ogr.cap.multithread;

public class MainPrint {
public static void main(String args[]){
	//PrintWord printWord=new PrintWord("capgemini");
	/*PrintWord pt=new PrintWord("Narendra");
	PrintWord ptw=new PrintWord("Welcome to My world");
	printWord.start();
	pt.start();
	ptw.start();*/
	final PrintWord pt=new PrintWord();
	
	Thread t1=new Thread(){
		public void run(){
			pt.print("capgemini");
		}
	};
	Thread t2=new Thread(){
		public void run(){
			pt.print("Narendra");
		}
	};
	Thread t3=new Thread(){
		public void run(){
			pt.print("Welcome to my world");
		}
	};
	t1.start();
	t2.start();
	t3.start();
	
}
}
