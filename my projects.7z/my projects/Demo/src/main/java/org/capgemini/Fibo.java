package org.capgemini;

import java.util.Scanner;

class CalFibo{
	int num;
	private Scanner sc;
	void getDetail(){
		sc = new Scanner(System.in);
		System.out.println("Enter length of the series");
		num=sc.nextInt();
	}
	void cal(){
		int a=0,b=1,c;
		System.out.print("0,1, ");
		for(int i=0;i<=num-3;i++){
			c=a+b;
			System.out.print(c+", ");
			a=b;
			b=c;
		}
		
	}
}
public class Fibo {
	public static void main(String args[]){
		CalFibo c1=new CalFibo();
		c1.getDetail();
		c1.cal();
		
	}

}
