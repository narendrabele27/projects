package org.capgemini;

public class Armstrong {
	public static void main(String args[]){
			
	int num=1000,sum=0,r;
	
	for (int i=1;i<=num;i++){
		int temp=i;
		while (temp!=0){
			r=temp%10;
			sum=sum+(r*r*r);
			temp=temp/10;
		}
			if (i==sum){
				System.out.print(i+", ");
			}
			sum=0;
			
		}
		
	}

}

