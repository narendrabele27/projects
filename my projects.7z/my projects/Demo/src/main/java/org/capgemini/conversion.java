package org.capgemini;



import java.util.Scanner;




 class Word {
	public void pw(int n,String ch)
	{
		String one[]={" ","one","two","three","four","five","six","seven","eight","nine","ten","eleven",
				"twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"};
		String ten[]={" "," ","twenty","thirty","fourty","fifty","sixty","seventy","eighty","ninety"};
		

if(n>19)
		{
			System.out.print(ten[n/10]+" "+one[n%10]);
		}
		
		else
		{
			System.out.print(one[n]);
		}
		if(n>0)
		{
			System.out.print(ch);
		}
	}
 }
 
public class conversion
	{
		public static void main(String args[])
		{
			int n=0;
			Scanner scanf=new Scanner(System.in);
			System.out.println("Enter a number");
			n=scanf.nextInt();
			if(n<=0)
			{
				System.out.println("Enter numbers greater than zero");
			}
			else
			{
				Word a=new Word();
				a.pw(((n/1000)%100)," thousand ");
				a.pw(((n/100)%10)," hundred ");
				a.pw((n%100)," only");
			}
		}
	}
 


