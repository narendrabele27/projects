package org.capgemini;

import java.util.Scanner;

class Bonus{
	String   name;
	double salary;
	double bonus;
	void employeeDetail(){
		System.out.println("Enter Employee name:-");
		Scanner sc= new Scanner(System.in);
		name=sc.next();
		System.out.println("Enter Employee Salary");
		salary=sc.nextDouble();
		
	}
	void cal_bonus(){
		if (salary<500000){
			bonus=(30*salary)/100;
			System.out.println("30% bonus will be added ");
			System.out.println("Bonus of "+name+" is "+bonus);
		}
		else if(salary<1000000){
			bonus=(25*salary)/100;
			System.out.println("25% bonus will be added ");
			System.out.println("Bonus of "+name+" is "+bonus);
		}
		else if (salary<2000000){
			bonus=(20*salary)/100;
			System.out.println("20% bonus will be added ");
			System.out.println("Bonus of "+name+" is "+bonus);
		}
		else if (salary>2000000){
			bonus=(15*salary)/100;
			System.out.println("15% bonus will be added ");
			System.out.println("Bonus of "+name+" is "+bonus);
		}
	}
}
public class Salary_Bonus {
public static void main(String args[]){
	Bonus b=new Bonus();
	b.employeeDetail();
	b.cal_bonus();
}
}
