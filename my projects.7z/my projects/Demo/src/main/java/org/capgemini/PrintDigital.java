package org.capgemini;


import java.util.Scanner;

public class PrintDigital {
	public static void main(String args[])
	{
		int i=0;
		String s=null;
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		do{
			System.out.println("enter a single number to convert to digital format:");
			i=sc.nextInt();
			toDigitalFormat(i);
			System.out.println("Do you want to continue? Y/N");
			s=sc.next();
			}while(s.equalsIgnoreCase("y"));
		System.out.println("Thank You.Have a nice Day!!(:");
		}
	
		
static void toDigitalFormat(int i){
		switch(i)
		{
		case 1:
			for(int a=0;a<=4;a++)
			{
				for(int b=0;b<=4;b++)
				{
					if(b==4)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				System.out.println("");
			}
		break;
		case 2:
			for(int a=0;a<=4;a++)
			{
				for(int b=0;b<=4;b++)
				{
					if(a==0||a==4||a==2||a==1&&b==4||a==3&&b==0)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				System.out.println("");
			}
		break;
 
case 3:
			for(int a=0;a<=4;a++)
			{
				for(int b=0;b<=4;b++)
				{
					if(a==0||a==4||a==2||b==4)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				System.out.println("");
			}
		break;
		case 4:
			for(int a=0;a<=4;a++)
			{
				for(int b=0;b<=4;b++)
				{
					if(b==4||a==2||a<2&&b==0)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				System.out.println("");
			}
		break;
 
case 5:
			for(int a=0;a<=4;a++)
			{
				for(int b=0;b<=4;b++)
				{
					if(a==0||a==4||a==2||a==1&&b==0||a==3&&b==4)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				System.out.println("");
			}
		break;
		case 6:
			for(int a=0;a<=4;a++)
			{
				for(int b=0;b<=4;b++)
				{
					if(a==0||a==4||a==2||b==0||a==3 &&b==4)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				System.out.println("");
			}
		break;
 
case 7:
			for(int a=0;a<=4;a++)
			{
				for(int b=0;b<=4;b++)
				{
					if(a==0||a+b==4)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				System.out.println("");
			}
		break;
		case 8:
			for(int a=0;a<=4;a++)
			{
				for(int b=0;b<=4;b++)
				{
					if(a==0||a==4||a==2||b==0||b==4)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				System.out.println("");
			}
		break;

case 9:
			for(int a=0;a<=4;a++)
			{
				for(int b=0;b<=4;b++)
				{
					if(a==0||a==4||a==2||b==4||a==1&&b==0)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				System.out.println("");
			}
		break;
		case 0:
			for(int a=0;a<=4;a++)
			{
				for(int b=0;b<=4;b++)
				{
					if(a==0||a==4||b==0||b==4)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				System.out.println("");
			}
		break;
			
		}
	}
	

}




 
