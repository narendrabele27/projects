app.controller('MyController',function($scope){
	$scope.names=["Food Items","cosmetics","clothing","groccery"];
});