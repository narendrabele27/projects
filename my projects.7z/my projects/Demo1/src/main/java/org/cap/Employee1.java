package org.cap;

import java.util.Scanner;

public class Employee1 {
	int emp_id;
	String first_name;
	String last_name;
	double salary;
	void getEmployeeDetails(){
		System.out.println("Enter Employee id ");
		Scanner sc=new Scanner(System.in);
		emp_id=sc.nextInt();
		System.out.println("Enter Fiest name of employee");
		first_name=sc.next();
		System.out.println("Entre last name of employee");
		last_name=sc.next();
		System.out.println("Enter employee salary");
		salary=sc.nextDouble();
		
		
	}
	public Employee1(int emp_id, String first_name, String last_name, double salary) {
		super();
		this.emp_id = emp_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.salary = salary;
	}
	
	void printEmployeeDetails(){
		System.out.println("Employee ID is : "+emp_id);
		System.out.println("First name of employee is : "+first_name);
		System.out.println("Last name of employee is : "+last_name);
		System.out.println("Salary of employee is : "+salary);
	}
	public boolean equals(Object obj){
		Employee1 emp=(Employee1)obj;
		if(this==emp)
			return true;
		else{
			if (this.emp_id==emp.emp_id){
				if(this.first_name==emp.first_name){
					if(this.last_name==emp.last_name){
						if(this.salary==emp.salary)
							return true;
					}
				}
			}
				
		}
		return false;
		
	}
}
