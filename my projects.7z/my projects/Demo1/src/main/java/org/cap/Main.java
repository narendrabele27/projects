package org.cap;

public class Main {
public static void main(String args[]){
	Employee1 emp1=new Employee1(1,"tom","jerry",2000);
	Employee1 emp2=new Employee1(1,"tom","jerry",2000);
	System.out.println(emp1.equals(emp2));
	System.out.println(emp1==emp2);
	
	
}
}
