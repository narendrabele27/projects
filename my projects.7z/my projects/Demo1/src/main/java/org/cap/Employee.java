package org.cap;

import java.util.Scanner;

public class Employee {
int emp_id;
String first_name;
String last_name;
float salary;
Weekdays holiday;

private Scanner sc;
void getEmployeeDetails(){
	sc = new Scanner(System.in);
	System.out.println("Enter Employee ID");
	emp_id=sc.nextInt();
	System.out.println("Enter Employee First name");
	first_name=sc.next();
	System.out.println("Enter Employee Last name");
	last_name=sc.next();
	System.out.println("Enter Employee salary");
	salary=sc.nextFloat();
	System.out.println("Enter your choice");
	System.out.println("1.Monday");
	System.out.println("2.Tuesday");
	System.out.println("3.Wednesday");
	System.out.println("4.Thrusday");
	System.out.println("5.Friday");
	System.out.println("6.Satarday");
	System.out.println("7.Sunday");
	int choice =sc.nextInt();
	switch(choice){
	case 1:
		holiday=Weekdays.SUN;
		break;
	case 2:
		holiday=Weekdays.MON;
		break;
		
	}
	
	
			}

void printEmployeeDetails(){
	System.out.println("Employee ID is :"+emp_id);
	System.out.println("Employee First name is :"+first_name);
	System.out.println("Employee last name is:"+last_name);
	System.out.println("Employee salary is :"+ salary);
	//System.out.println(Weekdays.values(num));
}









}



