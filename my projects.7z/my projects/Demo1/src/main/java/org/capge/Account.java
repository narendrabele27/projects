package org.capge;

import java.util.Scanner;

public class Account {
	int account_no;
	String account_name;
	String open_date;
	String account_type;
	double amount;
	public Account(int account_no, String account_name, String open_date, String account_type, double amount) {
		super();
		this.account_no = account_no;
		this.account_name = account_name;
		this.open_date = open_date;
		this.account_type = account_type;
		this.amount = amount;
	}
	void getAccountDetails(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Account number");
		account_no=sc.nextInt();
		System.out.println("Enter Account name");
		account_name=sc.next();
		System.out.println("Enter Account open date");
		open_date=sc.next();
		System.out.println("Enter Account type");
		account_type=sc.next();
		System.out.println("Enter Amount in the account");
		amount=sc.nextDouble();
		
	}
	void printAccountDetails(){
		System.out.println("Account number is: "+account_no);
		System.out.println("Account name is: "+account_name);
		System.out.println("Account open date is: "+open_date);
		System.out.println("Account type is :"+account_type);
		System.out.println("Amount balance is: "+amount);
	}
	

}
