
package org.capge;

public interface TransactionDAO {
public int  saveAccount(Account acc,Account arr1[]);
public double withdraw();
public double deposite();

}
