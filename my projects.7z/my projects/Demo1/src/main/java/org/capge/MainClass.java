package org.capge;

public class MainClass {

	public static void main(String[] args) {
		 Account arr[] =new Account[100];
		int i=0;
		TransactionDAO tr=new TransactionDAO_Implements_Class(i, null, null, null, i);
		tr.saveAccount(new Account(, arr[i]);
		

	}

}
