package org.capge;

import java.util.Scanner;

public class TransactionDAO_Implements_Class extends Account implements TransactionDAO {
	
	public TransactionDAO_Implements_Class(int account_no, String account_name, String open_date, String account_type,
			double amount) {
		super(account_no, account_name, open_date, account_type, amount);
		// TODO Auto-generated constructor stub
	}

	static int slotno=0;
	public int saveAccount(Account acc, Account arr1[]) {
		
		return 0;
	}

	public double withdraw() {
		// TODO Auto-generated method stub
		return 0;
	}

	public double deposite() {
		// TODO Auto-generated method stub
		double deposite_amount;
		System.out.println("Entre Deposite Amount");
		Scanner sc =new Scanner(System.in);
		deposite_amount=sc.nextDouble();
		amount=amount+deposite_amount;
		return amount;
	}
	

}
