import java.util.Scanner;

public class MonthlySalaryEmployee extends Employee{
	int no_of_days;
	float salary_per_day=1000;
	
	
	double claculateSalary() {
		System.out.println("Enter number of days employee worked");
		Scanner sc=new Scanner(System.in);
		no_of_days=sc.nextInt();
		salary=no_of_days*salary_per_day;
		return salary;
	}
	

}
