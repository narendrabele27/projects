import java.util.Scanner;

public abstract class Employee {
int emp_id;
String first_name;
String last_name;
double salary;
void getEmployeeDetails(){
	System.out.println("Enter Employee id ");
	Scanner sc=new Scanner(System.in);
	emp_id=sc.nextInt();
	System.out.println("Enter Fiest name of employee");
	first_name=sc.next();
	System.out.println("Entre last name of employee");
	last_name=sc.next();
	
}
void printEmployeeDetails(){
	System.out.println("Employee ID is : "+emp_id);
	System.out.println("First name of employee is : "+first_name);
	System.out.println("Last name of employee is : "+last_name);
	System.out.println("Salary of employee is : "+claculateSalary());
}
 abstract double claculateSalary();
}
