import java.util.Scanner;

public class WeeklysalaryEmployee extends Employee {
float no_of_hours;
float salary_per_hours=200;


double claculateSalary() {
	System.out.println("Entre number of hours Employee worked");
	Scanner sc=new Scanner(System.in);
	no_of_hours=sc.nextFloat();
	
	salary=(no_of_hours*salary_per_hours);
	return salary;
}


}
