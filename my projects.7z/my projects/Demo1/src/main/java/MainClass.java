import java.util.Scanner;

public class MainClass {
public static void main(String args[]){
	int ch;
	Employee emp=null;
	System.out.println("1.Weekly salary Employee");
	System.out.println("2.Monthly salary Employee");
	System.out.println("Enter our choice");
	Scanner sc=new Scanner(System.in);
	ch=sc.nextInt();
	if (ch==1){
		emp=new WeeklysalaryEmployee();
		emp.getEmployeeDetails();
		emp.printEmployeeDetails();
	}
	else if(ch==2){
		emp=new MonthlySalaryEmployee();
		emp.getEmployeeDetails();
		emp.printEmployeeDetails();
	}
	else 
		System.out.println("Enter valid choice");
}
}
