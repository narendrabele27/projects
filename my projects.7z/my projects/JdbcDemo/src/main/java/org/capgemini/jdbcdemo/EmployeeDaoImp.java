package org.capgemini.jdbcdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EmployeeDaoImp implements EmployeeDao {

	public int addEmployee(Employee1 employee) {
		int count=0;
		String sql="insert into employee1 values(?,?,?,?,?,?)";
		try {
			PreparedStatement pst=getMySQlConnection().prepareStatement(sql);
			pst.setInt(1, employee.getEmpid());
			pst.setString(2, employee.getFristname());
			pst.setString(3, employee.getLastname());
			pst.setDouble(4, employee.getSalary());
			pst.setInt(5, employee.getDepartid().getDepartid());
			pst.setString(6, employee.getEmailid());
			
			count=pst.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return count;
		
	}
	
	
	
	public  Connection getMySQlConnection(){
		
		Connection conn=null;
		try {
			
			//Load Driver Class
			Class.forName("com.mysql.jdbc.Driver");
			
			//Establish Connection
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}
	

}
