package org.capgemini.jdbcdemo;

import java.util.Scanner;

public class UserInteraction {

	Scanner sc=new Scanner(System.in);
	
	
	public Employee1 getEmployee(){
		Employee1 emp=new Employee1();
		System.out.println("Enter Employee ID");
		emp.setEmpid(sc.nextInt());
		System.out.println("Enter Employee firstname");
		emp.setFristname(sc.next());
		System.out.println("Enter Employee lastname");
		emp.setLastname(sc.next());
		System.out.println("Enter Employee salary");
		emp.setSalary(sc.nextDouble());
		System.out.println("Enter Employee department Id");
		Department department=new Department();
		department.setDepartid(sc.nextInt());
		System.out.println("Entre employee email Id");
		emp.setEmailid(sc.next());
		return emp;
	}
	
	public String printMessage(int value){
		if(value>0)
			return "Record Inserted";
		else
			return "Record Insertion error!";
	}
	
}
