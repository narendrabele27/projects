package org.capgemini.jdbcdemo;

public class Department {
 private int  departid;
 private String departname;
 
 
 
 
 public Department(){
	 
 }
 
public Department(int departid, String departname) {
	super();
	this.departid = departid;
	this.departname = departname;
}
public int getDepartid() {
	return departid;
}
public void setDepartid(int departid) {
	this.departid = departid;
}
public String getDepartname() {
	return departname;
}
public void setDepartname(String departname) {
	this.departname = departname;
}

@Override
public String toString() {
	return "Department [departid=" + departid + ", departname=" + departname + "]";
}
 
 
 
}
