package org.capgemini.jdbcdemo;

public class Employee1 {
	private int empid;
	private String fristname;
	private String lastname;
	private double salary;
	private Department departid;
	private String emailid;
	
	
	
	public Employee1(){
		
	}
	
	
	public Employee1(int empid, String fristname, String lastname, double salary, Department departid, String emailid) {
		super();
		this.empid = empid;
		this.fristname = fristname;
		this.lastname = lastname;
		this.salary = salary;
		this.departid = departid;
		this.emailid = emailid;
	}

	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getFristname() {
		return fristname;
	}
	public void setFristname(String fristname) {
		this.fristname = fristname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public Department getDepartid() {
		return departid;
	}


	public void setDepartid(Department departid) {
		this.departid = departid;
	}


	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}


	@Override
	public String toString() {
		return "Employee1 [empid=" + empid + ", fristname=" + fristname + ", lastname=" + lastname + ", salary="
				+ salary + ", departid=" + departid + ", emailid=" + emailid + "]";
	}
	
	
	
	

}
