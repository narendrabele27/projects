package org.capgemini.jdbcdemo;

public class Boot {

	public static void main(String[] args) {
		UserInteraction ui=new UserInteraction();
		EmployeeDao empDao=new EmployeeDaoImp();
		
		
		Employee1 emp=ui.getEmployee();
		int count=empDao.addEmployee(emp);
		System.out.println(ui.printMessage(count));

	}

}
