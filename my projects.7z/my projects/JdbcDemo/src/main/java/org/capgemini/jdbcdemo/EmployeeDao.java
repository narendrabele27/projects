package org.capgemini.jdbcdemo;

public interface EmployeeDao {
	public int addEmployee(Employee1 employee);

}
