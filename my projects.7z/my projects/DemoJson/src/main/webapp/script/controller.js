app.controller("mycontroller",function($scope,$http){
	
	$scope.getcategory=function(){
	var url="http://localhost:8080/DemoJson/GetCategoryservlet";
	$http.get(url)
	.success(function(response){
		$scope.prod=response;
	})
	.error(function(msg){
		$scope.prod=msg;
	});

	};
});