package org.cap.json;

public class Product {
	private int product_Id;
	private String product_Name;
	private Category category;
	private int quantity;
	private double price;
	
	
	
	
	public Product(){}
	
	
	
	public Product(int product_Id, String product_Name, Category category, int quantity, double price) {
		super();
		this.product_Id = product_Id;
		this.product_Name = product_Name;
		this.category = category;
		this.quantity = quantity;
		this.price = price;
	}
	
	public int getProduct_Id() {
		return product_Id;
	}
	public void setProduct_Id(int product_Id) {
		this.product_Id = product_Id;
	}
	public String getProduct_Name() {
		return product_Name;
	}
	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "Product [product_Id=" + product_Id + ", product_Name=" + product_Name + ", quantity=" + quantity
				+ ", price=" + price + "]";
	}
	
	
	

}
