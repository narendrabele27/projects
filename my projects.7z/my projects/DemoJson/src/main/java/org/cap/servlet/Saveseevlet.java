package org.cap.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.dao.ProductDaoImpl;
import org.cap.json.Category;
import org.cap.json.Product;


public class Saveseevlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProductDaoImpl productDaoImpl=new ProductDaoImpl();
		String prodname=request.getParameter("pName");
		String categoryName=request.getParameter("categoryName");
		String quantity=request.getParameter("qty");
		String price=request.getParameter("price");
		for(Category cat:productDaoImpl.getAllCategory()){
			
		}
		Product product=new Product();
		product.setProduct_Name(prodname);
		product.setPrice(Double.parseDouble(price));
		//product.setCategory();
		
	}

}
