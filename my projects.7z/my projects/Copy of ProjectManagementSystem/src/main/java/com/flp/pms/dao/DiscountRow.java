package com.flp.pms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.flp.pms.domain.Discount;

public class DiscountRow implements RowMapper<Discount> {

	@Override
	public Discount mapRow(ResultSet rs, int count) throws SQLException {
		Discount discount=new Discount();
		discount.setDiscount_Id(rs.getInt("discountId"));
		discount.setDiscount_Name(rs.getString("discountName"));
		discount.setDiscription(rs.getString("description"));
		discount.setDiscount_percentage(rs.getDouble("discount_percentage"));
		discount.setValid_through(rs.getDate("validThru"));
		return discount;
	}

}
