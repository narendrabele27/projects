package com.flp.pms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.flp.pms.domain.Supplier;

public class SupplierRow implements RowMapper<Supplier> {

	@Override
	public Supplier mapRow(ResultSet rs, int count) throws SQLException {
		Supplier supplier=new Supplier();
		supplier.setSupplier_Id(rs.getInt("supplierId"));
		supplier.setFirst_Name(rs.getString("firstName"));
		supplier.setLast_Name(rs.getString("lastName"));
		supplier.setAddress(rs.getString("address"));
		supplier.setCity(rs.getString("city"));
		supplier.setState(rs.getString("state"));
		supplier.setPincode(rs.getString("pincode"));
		supplier.setContact_Number(rs.getString("contactno"));
		return supplier;
	}

}
