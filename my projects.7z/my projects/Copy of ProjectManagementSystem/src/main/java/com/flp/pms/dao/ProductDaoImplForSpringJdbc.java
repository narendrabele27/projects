package com.flp.pms.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public class ProductDaoImplForSpringJdbc implements IProductDao {
	private JdbcTemplate jdbcTemplate;
	private DataSource dataSource;
	
	
	

	public void setDatasource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate=new JdbcTemplate(dataSource);
	}

	@Override
	public List<Category> getAllCategory() {
		String sql="select * from category";
		List<Category> categories=jdbcTemplate.query(sql, new CategoryRow());
		return categories;
	}

	@Override
	public List<SubCategory> getAllSubCategory() {
		String sql="select * from subcategory";
		List<SubCategory> subCategories=jdbcTemplate.query(sql, new SubCategoryRow());
		return subCategories;
	}

	@Override
	public List<Supplier> getAllSuppliers() {
		String sql="select * from supplier";
		List<Supplier> suppliers=jdbcTemplate.query(sql, new SupplierRow());
		return suppliers;
	}

	@Override
	public List<Discount> getAllDiscounts() {
		String sql="select * from discount";
		List<Discount> discounts=jdbcTemplate.query(sql, new DiscountRow());
		return null;
	}

	@Override
	public void addProduct(Product product) {
		String sql="insert into product values(?,?,?,?,?,?,?,?,?,?)";
		jdbcTemplate.update(sql, new Object[]{product.getProduct_Name(),product.getDescription(),product.getManufacturing_Date(),
				product.getExpiry_Date(),product.getMaximum_Retail_Price(),product.getCategory().getCategory_Id(),
				product.getSubCategory().getSubCategory_Id(),product.getSupplier().getSupplier_Id(),product.getQuantity(),product.getRating()});
		
	}

	@Override
	public Map<Integer, Product> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> viewAllProductList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateProductName(Product product, String productName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateExpiryDate(Product product, Date expiryDate) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateMaxRetailPrice(Product product, double mrp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateRating(Product product, float rating) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCategory(Product product, Category category) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteProduct(int product_Id) {
		// TODO Auto-generated method stub
		
	}

}
