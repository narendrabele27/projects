package com.flp.pms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.SubCategory;

public class SubCategoryRow implements RowMapper<SubCategory> {

	@Override
	public SubCategory mapRow(ResultSet rs, int count) throws SQLException {
		SubCategory subCategory=new SubCategory();
		subCategory.setSubCategory_Id(rs.getInt("sub_category_Id"));
		subCategory.setSubCategory_Name(rs.getString("sun_category_Name"));
		int categoryId=rs.getInt("category_Id");
		ProductDaoImplForSpringJdbc springJdbc=new ProductDaoImplForSpringJdbc();
		List<Category> categories= springJdbc.getAllCategory();
		for(Category category:categories){
			if(category.getCategory_Id()==categoryId){
				subCategory.setCategory(category);
			}
		}
			
		return subCategory;
	}

}
